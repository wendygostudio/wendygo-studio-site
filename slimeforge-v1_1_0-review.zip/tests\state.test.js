import test from 'node:test';
import assert from 'node:assert/strict';
import { freshState, sanitizeImportedState, sanitizeVisitPayload, mergeConcurrentValue, applyElapsed, SAVE_SCHEMA } from '../common/logic.js';

const dna = (name = 'Mochi') => ({
  v: 1, species: 'gato', color: '#e8a33d', gender: 'hembra', accessory: 'none', cos: {},
  marking: { type: 'none', color: '#4a4038' }, temperament: 'tranquilo', name, seed: 42
});

test('rechaza archivos que no son partidas', () => {
  assert.throws(() => sanitizeImportedState(null), /save_not_object/);
  assert.throws(() => sanitizeImportedState({ phase: 'unknown' }), /save_bad_phase/);
  assert.throws(() => sanitizeImportedState({ schema: SAVE_SCHEMA + 1, phase: 'egg' }), /save_newer_version/);
});

test('normaliza límites y elimina propiedades desconocidas', () => {
  const imported = sanitizeImportedState({
    phase: 'pet', dna: dna('  Michi\u0000  '), brasas: -900, hambre: 999,
    stageIdx: 999, reserve: new Array(40).fill({ phase: 'pet', dna: dna('Reserva') }),
    unknownPayload: '<script>', demoMode: true
  }, freshState());
  assert.equal(imported.schema, SAVE_SCHEMA);
  assert.equal(imported.brasas, 0);
  assert.equal(imported.hambre, 100);
  assert.equal(imported.stageIdx, 4);
  assert.equal(imported.reserve.length, 25);
  assert.equal(imported.dna.name, 'Michi');
  assert.equal(imported.demoMode, false);
  assert.equal('unknownPayload' in imported, false);
});

test('una importación no rejuvenece el trial ni sustituye la licencia local', () => {
  const now = Date.now();
  const current = freshState();
  current.trialStart = now - 4 * 86400e3;
  current.trialSeen = 4 * 86400e3;
  current.pro = { active: true, tier: 'lifetime', key: 'local-only' };
  const imported = sanitizeImportedState({ phase: 'egg', trialStart: now, trialSeen: 0, pro: { active: true, key: 'foreign' } }, current);
  assert.equal(imported.trialStart, current.trialStart);
  assert.equal(imported.trialSeen, current.trialSeen);
  assert.equal(imported.pro.key, 'local-only');
});

test('el foco completado recompensa y limpia el temporizador', () => {
  const s = freshState();
  s.phase = 'pet'; s.dna = dna(); s.focus = { kind: 'work', startedAt: Date.now() - 1600e3, endsAt: Date.now() - 1, duration: 25 * 60000 };
  const oldRandom = Math.random; Math.random = () => 1;
  try { applyElapsed(s, 1000); } finally { Math.random = oldRandom; }
  assert.equal(s.focus, null);
  assert.ok(s.brasas >= 25);
  assert.equal(s.fstats.totalN, 1);
  assert.equal(s.fstats.totalMin, 25);
});

test('los códigos de visita se acotan antes de dibujar el SVG', () => {
  const p = sanitizeVisitPayload({ dna: { ...dna('<b>Michi</b>'), color: '" onload="bad' }, stage: 999, owner: 'Amigo\u0000<script>' });
  assert.equal(p.dna.color, '#e8a33d');
  assert.equal(p.stage, 4);
  assert.equal(p.owner.includes('\u0000'), false);
  assert.equal(p.owner.length <= 14, true);
});

test('la fusión concurrente conserva recompensas independientes', () => {
  const base = { brasas: 10, mats: { hilo: 0, escama: 0 } };
  const popup = { brasas: 8, mats: { hilo: 1, escama: 0 } };
  const worker = { brasas: 18, mats: { hilo: 0, escama: 1 } };
  assert.deepEqual(mergeConcurrentValue(base, popup, worker), { brasas: 16, mats: { hilo: 1, escama: 1 } });
});
